package calculator;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 * <p> Title: testCasesOfCal Class. </p>
 * 
 * <p> Description: Test cases class</p>
 * 
 * @author  Shivam Singhal
 * @version 1.00 2017-05-22 The JavaFX-based GUI for the implementation of a calculator
 */

public class testCasesOfCal {
	@Test
	public void testOne() {

		int roll = 170030;
		int twodif = 10;
		int mul = roll*twodif;
		int mul2=initiateSum(roll, twodif);
		assertEquals(mul,mul2);
	}
	public int initiateSum(int rol,int dig) {
		int roll2 = rol;
		int dig2 = dig;
		int mul = roll2*dig2;
		return mul;
	}

}