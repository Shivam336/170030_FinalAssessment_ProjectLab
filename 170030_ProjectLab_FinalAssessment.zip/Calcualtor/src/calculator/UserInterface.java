package calculator;

import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.stage.Stage;

/**
 * <p> Title: UserInterface Class. </p>
 * 
 * <p> Description: The Java/FX-based user interface for the calculator. The class works with String
 * objects and passes work to other classes to deal with all other aspects of the computation.</p>
 * 

 * 
 * @author  Shivam Singhal
 * @version 4.00 2017-05-22 The JavaFX-based GUI for the implementation of a calculator
 */

public class UserInterface {


	/**********************************************************************************************

Attributes

	 **********************************************************************************************/

	/* Constants used to parameterize the graphical user interface.  We do not use a layout manager for
   this application. Rather we manually control the location of each graphical element for exact
   control of the look and feel. */
	private final double BUTTON_WIDTH = 40;
	private final double BUTTON_OFFSET = BUTTON_WIDTH / 2;
	private Button button_Def = new Button("Manage Variables and Constants");
	// These are the application values required by the user interface
	private Label label_UNumberCalculator = new Label("Calculator");
	private Label label_Operand1 = new Label("Roll Number");
	private static TextField text_Operand1 = new TextField();
	private Label label_Operand2 = new Label("Two Digit Number");
	private static TextField text_Operand2 = new TextField();
	private Label label_Result = new Label("Result ");
	public static TextField text_Result = new TextField();
	public static String resu ="";
	private Button button_Add = new Button("Calculate");
	
	public static Button button_Launch2 = new Button("Launch");

	private double buttonSpace; // This is the white space between the operator buttons.

	Stage primaryStage = new Stage();


	/**********************************************************************************************
		Constructors
	 **********************************************************************************************/

	/**********
	 * This method initializes all of the elements of the graphical user interface. These assignments
	 * determine the location, size, font, color, and change and event handlers for each GUI object.
	 */

	public UserInterface(Pane theRoot) {
		// There are six gaps. Compute the button space accordingly.
		buttonSpace = Calculator.WINDOW_WIDTH / 6;

		// Label theScene with the name of the calculator, centered at the top of the pane
		setupLabelUI(label_UNumberCalculator, "Arial", 24, Calculator.WINDOW_WIDTH, Pos.CENTER, 0, 10);

		// Label the first operand just above it, left aligned
		setupLabelUI(label_Operand1, "Arial", 18, Calculator.WINDOW_WIDTH-10, Pos.BASELINE_LEFT, 10, 70);

		// Establish the first text input operand field and when anything changes in operand 1,
		// process both fields to ensure that we are ready to perform as soon as possible.
		setupTextUI(text_Operand1, "Arial", 18, 400, Pos.BASELINE_LEFT, 180, 70, true);
				
		// Establish an error message for the first operand just above it with, left aligned
		// Label the Second operand just above it, left aligned
		setupLabelUI(label_Operand2, "Arial", 18, Calculator.WINDOW_WIDTH-10, Pos.BASELINE_LEFT, 10, 160);

		// Establish the second text input operand field and when anything changes in operand 2,
		// process both fields to ensure that we are ready to perform as soon as possible.
		setupTextUI(text_Operand2, "Arial", 18, 400, Pos.BASELINE_LEFT, 180, 160, true);


		// Label the result just above the result output field, left aligned
		setupLabelUI(label_Result, "Arial", 18, Calculator.WINDOW_WIDTH-10, Pos.BASELINE_LEFT, 10, 300);

		// Establish the result output field.  It is not editable, so the text can be selected and copied, 
		// but it cannot be altered by the user.  The text is left aligned.
		setupTextUI(text_Result, "Arial", 18, 400, Pos.BASELINE_LEFT, 180, 300, false);

		// Establish the ADD "+" button, position it, and link it to methods to accomplish its work
		setupButtonUI(button_Add, "Symbol", 32, BUTTON_WIDTH, Pos.BASELINE_LEFT, 1 * buttonSpace-BUTTON_OFFSET, 230);
		button_Add.setOnAction((event) -> {initiateSum(text_Operand1.getText(),text_Operand2.getText());});

		




		// Place all of the just-initialized GUI elements into the pane
		theRoot.getChildren().addAll(label_UNumberCalculator, label_Operand1, text_Operand1, 
				label_Operand2, text_Operand2,  label_Result, text_Result,  
				button_Add);
	}


	/**********
	 * Private local method to initialize the standard fields for a label
	 */
	private void setupLabelUI(Label l, String ff, double f, double w, Pos p, double x, double y){
		l.setFont(Font.font(ff, f));
		l.setMinWidth(w);
		l.setAlignment(p);
		l.setLayoutX(x);
		l.setLayoutY(y); 
	}

	/**********
	 * Private local method to initialize the standard fields for a text field
	 */
	private void setupTextUI(TextField t, String ff, double f, double w, Pos p, double x, double y, boolean e){
		t.setFont(Font.font(ff, f));
		t.setMinWidth(w);
		t.setMaxWidth(w);
		t.setAlignment(p);
		t.setLayoutX(x);
		t.setLayoutY(y); 
		t.setEditable(e);
	}

	/**********
	 * Private local method to initialize the standard fields for a button
	 */
	private void setupButtonUI(Button b, String ff, double f, double w, Pos p, double x, double y){
		b.setFont(Font.font(ff, f));
		b.setMinWidth(w);
		b.setAlignment(p);
		b.setLayoutX(x);
		b.setLayoutY(y); 
	}


	/**********************************************************************************************

		User Interface Actions

	 **********************************************************************************************/

	/********************
	 * enterValues() routine sets the values of empty operands to zero and empty error term fields to 5 
	 ****/
	

	public static String  initiateSum(String roll, String dig){
		int roll2 = Integer.parseInt(text_Operand1.getText());
		int dig2 = Integer.parseInt(text_Operand2.getText());
		int mul = roll2*dig2;
		 resu = String.valueOf(mul);
		text_Result.setText(resu);
		return resu;
	}
}
